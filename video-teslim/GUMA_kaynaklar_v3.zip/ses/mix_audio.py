from pathlib import Path
import json,re,subprocess,hashlib,os
OUT=Path('/workspace/guma-video/v3/audio')
def run(cmd,log):
    p=subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,check=True)
    (OUT/log).write_text(p.stderr);return p.stderr
base=['ffmpeg','-hide_banner','-nostdin','-threads','2','-y']
run(base+['-i',str(OUT/'narration-master.wav'),'-i',str(OUT/'sound-design.wav'),'-filter_complex','[0:a]pan=stereo|c0=c0|c1=c0,apad=whole_dur=164.2[v];[v][1:a]amix=inputs=2:duration=longest:normalize=0,atrim=duration=164.2[a]','-map','[a]','-t','164.2','-ar','48000','-ac','2','-c:a','pcm_s24le',str(OUT/'mix-before-normalize.wav')],'mix.log')
analysis=run(base+['-i',str(OUT/'mix-before-normalize.wav'),'-af','loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json','-f','null','-'],'mix-loudnorm-analysis.log')
d=json.loads(re.findall(r'\{[\s\S]*?\}',analysis)[-1])
f=f'loudnorm=I=-16:TP=-1.5:LRA=7:measured_I={d["input_i"]}:measured_TP={d["input_tp"]}:measured_LRA={d["input_lra"]}:measured_thresh={d["input_thresh"]}:offset={d["target_offset"]}:linear=false:print_format=json'
run(base+['-i',str(OUT/'mix-before-normalize.wav'),'-af',f,'-t','164.2','-ar','48000','-ac','2','-c:a','pcm_s24le',str(OUT/'finalmix.wav')],'final-mix-loudnorm.log')
measure=run(base+['-i',str(OUT/'finalmix.wav'),'-af','loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json','-f','null','-'],'final-mix-verification.log')
m=json.loads(re.findall(r'\{[\s\S]*?\}',measure)[-1])
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration:stream=sample_rate,channels,codec_name','-of','json',str(OUT/'finalmix.wav')],text=True))
run(['ffmpeg','-v','error','-nostdin','-xerror','-threads','2','-i',str(OUT/'finalmix.wav'),'-f','null','-'],'full-decode.log')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(OUT/'narration-master.wav')==sha(Path('/workspace/guma-video/v2/audio/narration-master.wav'))
assert sha(OUT/'segments.json')==sha(Path('/workspace/guma-video/v2/audio/segments.json'))
assert sha(OUT/'narration.srt')==sha(Path('/workspace/guma-video/v2/audio/narration.srt'))
result={'duration_seconds':float(probe['format']['duration']),'sample_rate':48000,'channels':2,'codec':'PCM 24-bit','integrated_loudness_LUFS':float(m['input_i']),'true_peak_dBTP':float(m['input_tp']),'loudness_range_LU':float(m['input_lra']),'voice_speed_changed':False,'voice_duration_seconds':155.167313,'voice_and_caption_files_identical_to_v2':True,'voice_SHA256':sha(OUT/'narration-master.wav'),'original_audio_source':'New user-supplied ElevenLabs narration only; source GUMA video audio never used.','music_source':'Original deterministic 92 BPM sine/noise synthesis, no sampled music; see make_sound_design.py.','foley_source':'Original noise/oscillator synthesis: paper flips, pencil traces, soft mechanical clicks, air swishes, soft number impact, final chime. See sfx-events.json.','music_ducking':'Driven by actual narration envelope, up to approx9dB; Foley mild duck; slow release.','sources_card_seconds':[155.2,162.2],'follow_animation_seconds':[162.2,164.2],'caption_timing_limitation':'Unchanged v2 caption timing; within-sentence phrase boundaries approximate.','full_audio_decode':'passed'}
assert abs(result['duration_seconds']-164.2)<.001
assert -16.2<=result['integrated_loudness_LUFS']<=-15.8
assert result['true_peak_dBTP']<=-1.45
(OUT/'finalmix.metadata.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
alias=OUT/'final-mix.wav'
if alias.exists():alias.unlink()
os.link(OUT/'finalmix.wav',alias)
print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
