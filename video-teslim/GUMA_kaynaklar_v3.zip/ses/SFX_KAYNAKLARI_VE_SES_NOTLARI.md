# GUMA v3 — ses kaynakları ve kullanım notları

## Nihai dosya

`finalmix.wav`: 164,2 saniye; PCM 24-bit, 48 kHz stereo. Instagram videosuna AAC olarak kodlanmaya uygun. Ölçülmüş LUFS, true peak ve teknik kontrol sonuçları `finalmix.metadata.json` içinde. `final-mix.wav` aynı verinin uyumluluk adıdır.

## Anlatıcı

Kullanıcının yüklediği `ElevenLabs_2026-10-17T14_49_20_Ece_gen_sp100_s50_sb75_v4.mp3` kaydı kullanıldı. v2 için hazırlanmış normalize anlatıcı WAV dosyası birebir kopyalandı; konuşma içeriği, süresi ve hızı değişmedi. Kaynak GUMA/Fiinera videosunun orijinal sesinden, görüntüsünden veya karelerinden hiçbir parça bu ses dosyalarına alınmadı.

## Müzik ve efektlerin kaynağı

Tüm müzik ve efektler bu çalışma için `make_sound_design.py` ile üretildi. Kaynakları deterministik sinüs osilatörleri ve programın ürettiği filtrelenmiş gürültüdür. İnternetten müzik, ses kaydı, örnek/sample veya platform bildirim sesi kullanılmadı.

- Müzik: 92 BPM hafif editoryal ritim; yumuşak major/add9 akor dokuları, yuvarlak düşük sesli vuruşlar ve seyrek küçük pluck sesleri.
- Kâğıt efekti: geniş bant gürültüye geçiş zarfı ve küçük kısa lif benzeri kıtırtılar uygulanarak sentezlendi.
- Kalem/çizgi efekti: filtrelenmiş gürültüye hızlı düzensiz yoğunluk zarfı uygulanarak sentezlendi.
- Mekanik tık: kısa filtrelenmiş gürültü ve sönümlü osilatör birlikte üretildi.
- Hava geçişi: kısa filtrelenmiş gürültüden üretildi; alarm, siren veya dramatik yükselen ton içermez.
- 130 bin sayı yerleşmesi: kısa ve yumuşak düşük frekanslı vurgu ile hafif tık birlikte kullanıldı.
- Takip kapanışı: 162,27 ve 162,50 saniyede iki kısa, özgün sönümlü tını. Herhangi bir platformun bildirim sesini taklit etmez.

## Konuşmayla denge ve zamanlama

Müziğin ses seviyesi gerçek anlatıcı kaydının RMS zarfına göre düşürülür. 10 ms çözünürlükte analiz, hızlı giriş ve yavaş bırakma uygulanır; müzikte yaklaşık 9 dB'ye kadar, efektlerde daha hafif azaltma vardır. Böylece konuşma önde kalırken cümle aralarında müzik doğal olarak açılır. Alıntı ve ana soru bölümlerinde ritim seyreltilir.

36 ana görsel olaya farklı efektler eşlendi. Tam liste `sfx-events.json` içinde. Her geçişe aynı whoosh eklenmedi. Kaynak kartı 155,2–162,2; özgün takip kapanışı 162,2–164,2 saniyedir. Son iki saniyede müzik yumuşak biçimde söner.

## Altyazı

v2 `segments.json`, `narration.srt`, `sentences.json` ve temiz konuşma dökümü aynı bırakıldı. Caption ve anlatıcı dosyalarının SHA-256 eşitliği `mix_audio.py` içinde doğrulanır. 80 kısa caption vardır; en çok 7 kelime ve 2 satırdır. Cümle içindeki kısa parçaların sınırları yaklaşık zamanlamalardır.

## Yeniden üretim

1. Aynı normalize anlatıcı WAV ve caption dosyalarını bu klasöre yerleştir.
2. `python make_sound_design.py` çalıştır.
3. `python mix_audio.py` çalıştır.

İlk script ayrı müzik ve efekt katmanlarını da `music-bed.wav` ve `foley.wav` olarak kaydeder. İkinci script konuşmayla birleştirir, iki geçişli loudnorm uygular, tam dosyayı çözüp denetler ve ölçümleri kaydeder.
