# GUMA V3 — içerik ve görsel kontrolü

**Kontrol tarihi:** 17 Ekim 2026. **Kapsam:** güncel renderer, özgün nesne/kâğıt kart kodu, 20 sahnelik tasarım önizlemesi ve son düzeltmelerden sonra renderer üzerinden yeniden oluşturulan beş tam boy kare: şirket ifadesi, tasarım emeği, kurucu alıntısı, üretim şeması ve kaynak kartı.

## Kontrol edilen bağlam

- **50.000 TL:** “açıklanan bütçe planı” olarak etiketli; doğrulanmış gerçekleşen harcama iddiası yok.
- **130.000:** “önceki kitle beyanı” ve “kurucunun beyanı” olarak gösteriliyor. Güncel GUMA hesabı veya satış miktarı anlamı kurulmamış.
- **Üretim:** fabrika ve koltuk özgün, genel çizimler. “Temsili üretim / tedarik şeması” ve gerçek tesis/ürün görseli olmadığı yazıyor. Oklar üretim/tedarik ile satış rollerini gösteriyor; ücretsiz üretim, ortaklık oranı veya para transferi gösterilmiyor.
- **Aile açıklaması:** adlar arasındaki “Dayım” sözü gazetede aktarılan kurucu açıklamasına dayanıyor. Haluk Özbek'in görevi “haberdeki tanıtım” olarak sunuluyor. Genel fabrika ikonu gerçek tesis çizimi olarak tanıtılmıyor.
- **Alıntı kartı:** kısa söz doğru kişiye ve haber tarihine atfedilmiş. Kartta “Özgün bilgi kartı” yazıyor. Kâğıt, vurgu çizgileri ve yazı düzeni bu proje için hazırlanmış; bir gazete veya resmî belge ekran görüntüsü değil.
- **Son soru:** farklı çizgiler üzerindeki anonim profil ikonları “Temsili karşılaştırma” olarak etiketli; ölçülmüş başlangıç verisi iddiası yok.
- **Kaynaklar:** üç bilgi kaynağı ve kullanılan dokuz stok kimliği son kartta var. Tam adresler 2.028 karakterlik paylaşım açıklamasında bulunuyor. Stok kökeni/lisansının bağımsız teyit edilmediği kullanım notlarında açık.
- **Yasaklanan malzemeler:** kaynak GUMA/Fiinera videosunun özgün sesi, görüntüsü ve ekran kareleri ile kullanıcının referans videolarından alınmış görsel/ses öğeleri nihai renderer veya miks girdilerinde yok.

## Yapılan görsel düzeltmelerin yeniden kontrolü

- Şirket ifadesinin alt açıklaması koyu renge ve boş alana taşınmış; okunuyor.
- Aydınlık koltuk görüntüsünün üst başlığı için koyu üst vignette eklenmiş; metin görünür kalıyor.
- Açık kâğıt sahnelerinde koyu altyazı ve sade kaynak satırı kullanılıyor; gri sis kaldırılmış.
- Üretim rol etiketi koltuk nesnesinin arkasında kalmıyor.
- Şirket ifadesi ve bilgi birleştirme sahnelerinde görünmeyen stoklara yapılan atıflar kaldırılmış; özgün çizim satırı geliyor.
- Kurucu alıntısındaki hareketli vurgu, sözün içeriğini değiştirmiyor ve kaynak kartını örtmüyor.
- İncelenen karelerde kritik metin taşması, kesilme veya okunamayan kaynak yok.

**Sonuç:** İncelenen kapsamda kalan kritik içerik veya görsel düzeltme saptanmadı. Bu kontrol hukuki görüş veya lisans teyidi değildir. Nihai MP4'ün baştan sona teknik çözümlemesi, kare/süre/codec ve miks kontrolü ayrı teknik teslim kaydında tamamlanmalıdır; bu belge o kontrolün yapıldığını ileri sürmez.
