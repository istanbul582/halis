# GUMA V3 — kaynaklar ve kullanım notları

**Sürüm:** 17 Ekim 2026. Bu belge, nesneler, kâğıt bilgi kartları ve özgün çizimlerle kurulan yeni görsel sürüm içindir. Seslendirme ve bilgi içeriği V2 ile aynıdır; kaynak videonun özgün sesi, görüntüsü ve ekran kareleri kullanılmaz. Bu notlar, telif veya hukuki sorunsuzluk garantisi değildir.

## Bilgi kaynakları ve sınırları

### 1. “3 Ayda Milyonluk Marka Yaratıyoruz!”, 1. Gün

https://www.youtube.com/shorts/nnUXsnz3Wi0

Kullanıcının yüklediği özgün 44,801 saniyelik video araştırma amacıyla incelenmiştir. Ayrıntılı kayıt: `../../research_v5/video1/VIDEO1_KONTROL_NOTU.md`.

- Yaklaşık **00:13–00:20:** yaklaşık 50 bin lira sermayeyle başlama ve üç ay sonunda milyonun üzerinde değerlemeye ulaşmış bir marka oluşturmaya çalışma açıklaması. Bu bir **bütçe planı ve hedef**, gerçekleşen toplam harcama veya tamamlanmış sonuç belgesi değildir.
- Yaklaşık **00:02–00:07:** anlatıcı, daha önce 130 bin takipçiye ulaşıldığını söylüyor. Bu, videodaki geçmiş takipçi sayısı beyanıdır. Güncel GUMA hesabının ölçümü, mevcut müşteri sayısı veya izleyicilerin markaya dönüştüğü kanıtı değildir.
- Videonun sonunda fabrikalardan atıl kumaşları çok ucuza alma anlatımı da vardır. “Fabrika erişimini tamamen gizlediler” iddiası kullanılmaz.
- Kullanıcı, bu kaynağın **yalnızca atıflı kısa metin ve yeniden anlatımla** kullanılmasını istemiştir. Yeni seslendirmede kısa alıntı yer alır. Özgün konuşmacı sesi, ses klonu, video görüntüsü, ekran karesi veya kaynak videonun altyazı tasarımı kullanılmaz.

### 2. GUMA — Kullanım Şartları / Hizmet şartları

https://gumastore.com/pages/kullanim-sartlari

https://gumastore.com/policies/terms-of-service

Canlı sayfalar önceki araştırma aşamasında okunmuştur (HTTP 200). Kayıtlar: `../../research_v4/core/21.html`, `21.txt`, `08.html`, `08.txt` ve `manifest.json`. İki sayfa aynı şirket anlatımını büyük ölçüde tekrarlar; bağımsız iki teyit olarak sunulmaz.

Şirket, “bünyesinde bulunduğu Saloni Mobilya” ifadesini kullanıyor. Ürünler, Saloni tarafından üretilen ve GUMA aracılığıyla satılan ürünler olarak tanımlanıyor. Bu, **şirketin kendi açıklamasıdır**. Ortaklık oranları, bedelsiz üretim, kesin yatırım tutarı veya finansman şartları buradan çıkarılmaz. Şemalardaki oklar **üretim/tedarik ve satış rollerini** gösterir; mülkiyet, gizli finansman veya para transferi anlamına gelmez.

### 3. Yıldırım Gazetesi — “İnegöllü mobilyacı gençler inanılmazı başardı”

https://www.yildirimgazetesi.com/inegollu-mobilyaci-gencler-inanilmazi-basardi

**Haber tarihi:** 6 Ekim 2025, 20:00. **Yazar:** Yavuz Yılmaz. Canlı sayfa okunmuştur (HTTP 200). Kayıtlar: `../../research_v4/core/03.html`, `03.txt` ve `manifest.json`.

Haberde Yavuz Selim Bayraktar'ın “Dayım Haluk Özbek, Guma’nın doğuş hikayesinde önemli bir paya sahip” açıklaması aktarılıyor. Aynı haberde Özbek, Saloni Mobilya Yönetim Kurulu Başkanı olarak tanıtılıyor. Bayraktar'ın, dayısının bilgileriyle mobilya sektörünü tanımalarını sağladığı açıklaması da bulunuyor.

Videoda bu bilgiler **gazetede aktarılan kurucu açıklaması ve haberdeki tanıtım** olarak sunulur. Akrabalığın ayrıca resmî kayıtla doğrulandığı veya maddi desteğin koşullarının bilindiği ileri sürülmez. Kamuya açık açıklama, açıklanmış bir destek ilişkisini kaynaklandırır; aldatma veya gizleme niyetini kanıtlamaz.

## Özgün çizimler, bilgi kartları ve referans videoları

- Fabrika, koltuk, kumaş rulosu, kamera, kutu ve anonim profil nesneleri `objects.py` ile hazırlanmış özgün, genel amaçlı çizimlerdir. Gerçek bir tesisin, kişinin veya markanın ürününün kopyası değildir.
- Kâğıt üzerindeki bütçe, takipçi, üretim ve alıntı kartları `paper_assets.py` ile hazırlanmış **özgün bilgi kartlarıdır**. Haber, sözleşme, banka belgesi veya resmî kayıt ekran görüntüsü değildir. Sahte bir belge izlenimi vermek amacıyla oluşturulmamıştır; kaynak ve açıklama başlıkları görünürdür.
- “50.000 TL” kartı **açıklanan bütçe planı**, “130.000” kartı **önceki kitle beyanı** olarak etiketlenmiştir. İzleyici profil ikonları sayısal ölçüm veya gerçek kişi gösterimi değildir.
- Üretim sahnesi “Temsili üretim / tedarik şeması”, son iki başlangıç çizgisi “Temsili karşılaştırma” olarak belirtilir. Çizgilerin konumu veya nesne sayıları ölçülmüş veri değildir.
- Kullanıcının verdiği dört referans video yalnızca görsel anlatım incelemesinde kullanılmıştır. Bunlardan video karesi, ses, müzik, grafik nesne veya arayüz final kurgusuna aktarılmamıştır. Düzen, hareket ve nesneler proje koduyla yeniden kurulmuştur.
- GUMA ve Saloni adları inceleme konusunu tanımlamak için standart fontlarla yazılır; logoları veya özgün marka yazı biçimleri kullanılmaz. Instagram arayüzü ve takip butonu kopyalanmaz.

## Kullanılan dokuz stok dosyası

Dosyaları kullanıcı yüklemiş ve Pexels'ten indirdiğini bildirmiştir. Sayfa adresleri dosya adlarındaki sayısal kimliklerden oluşturulmuştur. **Dosya sayfası, yaratıcı adı, dosya eşleşmesi, indirme tarihindeki lisans ve özel izin kayıtları bağımsız doğrulanmamıştır.** Önceki kontrolde resmî Pexels lisans sayfası ile bazı dosya sayfalarına erişim, ağ geçidinde 403 ile engellenmiştir; dokuz sayfanın tümüne güncel erişim sağlandığı iddia edilmez.

| Kimlik | Temsili içerik | Kaynak adresi |
|---|---|---|
| 5823583 | İç mekân / masa detayı | https://www.pexels.com/video/5823583/ |
| 15887137 | Aydınlık koltuk / iç mekân | https://www.pexels.com/video/15887137/ |
| 15896900 | Koyu koltuk / iç mekân | https://www.pexels.com/video/15896900/ |
| 7806870 | Kamera ve telefonla çalışma | https://www.pexels.com/video/7806870/ |
| 5384976 | Tasarım sırasında eller | https://www.pexels.com/video/5384976/ |
| 6790438 | Ahşap / atölye çalışması | https://www.pexels.com/video/6790438/ |
| 12625256 | Telefon ve kurgu masası | https://www.pexels.com/video/12625256/ |
| 7677808 | Kumaş yakın planı | https://www.pexels.com/video/7677808/ |
| 12911888 | Kumaş dokusu | https://www.pexels.com/video/12911888/ |

Genel lisans: https://www.pexels.com/license/ . Stokların kaynak yolu, kırpma ve başlangıç zamanları `../stock/manifest.json` içindedir. Kadrajlar; yüz, belirgin logo ve duvar sanatı gibi unsurları mümkün olduğunca dışarıda bırakacak şekilde seçilmiştir. Küçük cihaz arayüzleri ve tasarım çizimleri bazı çalışma görüntülerinde tesadüfen görünebilir; bunlar markaya ilişkin kanıt olarak sunulmaz.

Bu görüntüler GUMA veya Saloni tesisi, personeli veya ürünü olarak gösterilmez. İlgili stok kimliği görüntünün altında “Temsili stok” satırında yer alır. Pexels atfı veya kullanıcının dosyayı sağlaması, üçüncü kişilere ait marka, tasarım, sanat eseri, kişi veya mekân haklarının tamamının temizlendiği anlamına gelmez.

## Yazı tipleri

Üç font da Google Fonts'un resmî `google/fonts` deposundan edinilmiş ve **SIL Open Font License 1.1** ile sunulmuştur. Lisans dosyaları kaynak paketine eklenmiştir.

| Font | Resmî kaynak | Yerel lisans |
|---|---|---|
| Manrope | https://github.com/google/fonts/tree/main/ofl/manrope | `../../fonts/Manrope-OFL.txt` |
| DM Serif Display | https://github.com/google/fonts/tree/main/ofl/dmserifdisplay | `../../fonts/DMSerifDisplay-OFL.txt` |
| Barlow Condensed ExtraBold | https://github.com/google/fonts/tree/main/ofl/barlowcondensed | `../../fonts/BarlowCondensed-OFL.txt` |

## Ses

Anlatıcı, kullanıcının sağladığı `ElevenLabs_2026-10-17T14_49_20_Ece_gen_sp100_s50_sb75_v4.mp3` kaydıdır. V2'nin normalize anlatıcı dosyası kullanılmış; konuşma içeriği, süresi ve hızı değiştirilmemiştir. Kullanım hakkı üretim tarihindeki ElevenLabs planına ve seçilen sesin koşullarına bağlıdır; abonelik bağımsız doğrulanmamıştır.

Müzik ve efektler V3 için sinüs osilatörleri ve filtrelenmiş program gürültüsüyle sentezlenmiştir. İnternetten müzik, örnek ses veya referans videoların sesi kullanılmamıştır. Ayrıntılı kaynak ve miks notu: `../audio/SFX_KAYNAKLARI_VE_SES_NOTLARI.md`; kaynak paketinde ayrıca bulunur.

## Gösterim ve süre

Kaynaklar seslendirilmez. Küçük kaynak satırları açık kâğıt zeminlerde koyu renkle, hareketli görüntülerde gerektiğinde koyu alt zemin üzerinde gösterilir; metinler bulanıklaştırılmaz. Son kaynak kartı **155,2–162,2 saniye**, özgün takip kapanışı **162,2–164,2 saniye** aralığındadır. Tamamlanan MP4'ün ölçülen süresi **164,2 saniye (2 dakika 44,2 saniye)**. Çözünürlük 1080×1920, kare hızı 30 fps; dosya H.264/AAC biçimindedir. Baştan sona çözümleme ve 39 örnek kare kontrolü tamamlanmıştır. Son ses ölçümü −16,02 LUFS ve −4,15 dBTP'dir. Teknik kayıt kaynak paketindeki `DOGRULAMA_V3.json` dosyasında bulunur.

Bu çalışma bir pazarlama ve başlangıç koşulları değerlendirmesidir. Başlık, görsel, ses ve altyazı birlikte değerlendirilir; küçük bir dipnot, aksi yöndeki yanıltıcı ana mesajı düzeltmek için kullanılmaz.
