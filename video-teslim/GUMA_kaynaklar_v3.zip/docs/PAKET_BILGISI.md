# GUMA V3 kaynak paketi

Yeni ana dosya adı: `GUMA_HAREKETLI_V3_1080x1920.mp4`. Video, dosya boyutunu küçük tutmak için bu ZIP'e eklenmemiştir.

- `ACIKLAMA_METNI.txt`: Instagram açıklaması; **2.028 karakter**, tam bilgi ve stok kaynak bağlantılarıyla birlikte.
- `KAYNAKLAR_VE_KULLANIM_NOTLARI.md`: üç bilgi kaynağı, dokuz stok dosyası, özgün çizimler ve kullanım sınırları.
- `SON_KART_VE_KAYNAK_ETIKETLERI.json`: kaynak ve son kart bilgileri.
- `altyazi/GUMA_TR.srt`: yeni anlatıcının altyazıları; konuşma V2'den değiştirilmemiştir.
- `metin/SESLENDIRME.txt`: kullanılan seslendirme metni.
- `ses/`: V3'ün özgün müzik/efekt kaynağı ve ölçüm notları; büyük WAV dosyaları eklenmemiştir.
- `lisanslar/`: Manrope, DM Serif Display ve Barlow Condensed için SIL OFL dosyaları.
- `stok/manifest.json`: kaynak kimlikleri, kadrajlar ve teknik stok çıktıları.

Toplam kurgu hedefi 164,2 saniyedir. Kaynak kartı 155,2–162,2, takip kapanışı 162,2–164,2 saniyedir. Nihai MP4'ün baştan sona çözümleme ve teknik dosya kontrolü bu paketteki görsel/içerik kontrolünden ayrı yapılır.
