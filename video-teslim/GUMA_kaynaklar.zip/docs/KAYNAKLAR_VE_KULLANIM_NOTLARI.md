# GUMA — yeni kurgu: kaynaklar ve kullanım notları

Bu belge, 17 Ekim 2026 tarihli yeni seslendirme ve kurgu içindir. Önceki `output/KAYNAKLAR_VE_KULLANIM_NOTLARI.md`, ilk video teslimini anlatır; oradaki erişim engeli ve süre bilgileri bu sürümün durumu değildir. Kaynak göstermek, tek başına telif izni veya hukuki sorunsuzluk güvencesi sağlamaz.

## Anlatımın dayanağı

### 1. “3 Ayda Milyonluk Marka Yaratıyoruz!”, 1. Gün

https://www.youtube.com/shorts/nnUXsnz3Wi0

- Kaynak, kullanıcının yüklediği 44,801 saniyelik özgün video üzerinden incelendi. Kontrol notları: `../../research_v5/video1/VIDEO1_KONTROL_NOTU.md`.
- Yaklaşık **00:13–00:20**: yaklaşık 50 bin lira sermayeyle başlama ve üç ay sonunda milyonun üzerinde değerlemeye ulaşmış bir marka oluşturmaya çalışma açıklaması. Bu bir **bütçe planı ve hedef**; gerçekleşen toplam harcama veya sonuç belgesi değildir. Değerleme hedefindeki para birimi kesinleştirilmez.
- Yaklaşık **00:02–00:07**: anlatıcı, daha önce 130 bin takipçiye ulaşıldığını söylüyor. Bu, videodaki geçmiş takipçi sayısı beyanıdır; bağımsız hesap ölçümü veya GUMA'nın güncel takipçi sayısı değildir.
- Videonun devamında fabrikalardan atıl kumaşların çok ucuza alınması da anlatılıyor. Bu nedenle fabrika bağlantısının hiç açıklanmadığı veya gizlendiği ileri sürülmüyor.
- Kullanıcının açık talebi doğrultusunda özgün ses, görüntü, ekran karesi, gömülü altyazı tasarımı veya ses klonu finalde **kullanılmaz**. Yeni anlatıcıyla kısa metin alıntısı ve doğru yeniden anlatım kullanılır.

### 2. GUMA — Kullanım Şartları / Hizmet şartları

https://gumastore.com/pages/kullanim-sartlari

https://gumastore.com/policies/terms-of-service

Canlı sayfalar önceki araştırma aşamasında başarıyla okunmuştur (HTTP 200); kayıtlar `../../research_v4/core/21.html`, `21.txt`, `08.html`, `08.txt` ve `manifest.json` içindedir. İki sayfa büyük ölçüde aynı şirket metnini taşıdığından bağımsız iki teyit olarak sunulmaz.

Metin, GUMA için “bünyesinde bulunduğu Saloni Mobilya” ifadesini kullanıyor. Ürünler “Saloni Mobilya tarafından üretilen ve Guma aracılığıyla satışa sunulan” ürünler olarak tanımlanıyor. Bu, şirketin kendi açıklamasıdır. Ortaklık payları, üretimin bedelsizliği, kesin yatırım miktarı veya tüm ürünlerin aynı üretim koşullarına tabi olduğu buradan çıkarılmaz.

### 3. Yıldırım Gazetesi — “İnegöllü mobilyacı gençler inanılmazı başardı”

https://www.yildirimgazetesi.com/inegollu-mobilyaci-gencler-inanilmazi-basardi

**Haber tarihi:** 6 Ekim 2025, 20:00. **Yazar:** Yavuz Yılmaz. Canlı sayfa okunmuştur (HTTP 200); kayıtlar `../../research_v4/core/03.html`, `03.txt` ve `manifest.json` içindedir.

Haber, Yavuz Selim Bayraktar'a şu açıklamayı atfediyor: “Dayım Haluk Özbek, Guma’nın doğuş hikayesinde önemli bir paya sahip.” Aynı metinde, Özbek Saloni Mobilya Yönetim Kurulu Başkanı olarak tanıtılıyor; Bayraktar'ın, dayısının bilgileriyle mobilya sektörünü tanımalarını sağladığı açıklaması aktarılıyor.

Videoda bu bilgiler **gazetede aktarılan kurucu açıklaması** olarak kullanılır. Akrabalığın ayrıca nüfus kaydıyla doğrulandığı veya maddi desteğin koşullarının bilindiği iddia edilmez. Bu haber, açıklanmış bir ilişkiyi kaynaklandırır; gizleme veya aldatma niyeti kanıtlamaz.

## Görsel ve metin sınırları

- **50.000 TL:** “Açıklanan bütçe planı”. “Gerçek toplam maliyet” veya “yalnızca harcanan para” yazılmaz.
- **130.000:** “Videoda aktarılan önceki takipçi sayısı”. Güncel takipçi sayısı, satış veya müşteriye dönüşüm olarak sunulmaz.
- **Saloni → GUMA:** Şemada ok, “üretim / tedarik → satış” ilişkisini gösterir. Mülkiyet, bedelsiz fabrika, gizli finansman veya para transferi anlamına gelen ikon ve ok kullanılmaz.
- **Aile desteği:** Atıflı kurucu alıntısı kullanılır. Aile bağlantısı tek başına haksızlık, suç veya başarının tek nedeni gibi sunulmaz.
- Genel stoklar “Temsili görüntü” olarak işaretlenir; GUMA veya Saloni tesisi, ürünü, çalışanı veya kurucusu gibi gösterilmez.
- “Yalan”, “kandırdılar”, “gizlediler” gibi kanıtlanmamış iddialar yazı, ses, kapak veya görsel imayla kurulmaz. Örneğin para transferi, suçlama rengi ve sahte ifşa belgeleri kullanılmaz.
- Kısa metin alıntıları özgün tasarım içinde gösterilir; kaynak sitelerin tüm tasarımı, ürün fotoğrafları veya marka logo biçimleri kopyalanmaz. Marka adları konuyu tanımlamak amacıyla standart fontla yazılır.

## Stok görüntülerin kaynağı

Dosyalar kullanıcı tarafından sağlanmıştır. Kullanıcı, Pexels'ten indirdiğini bildirmiştir. Sayısal dosya kimliklerinden aşağıdaki kaynak adresleri oluşturulmuştur; **dosya sayfası, üretici adı, dosya eşleşmesi ve indirme anındaki lisans/özel izin kayıtları bağımsız doğrulanmamıştır**. Kaynak etiketi bu sınırı ortadan kaldırmaz.

| Dosya kimliği | Kaynak adresi |
|---|---|
| 7677808 | https://www.pexels.com/video/7677808/ |
| 12911888 | https://www.pexels.com/video/12911888/ |
| 7679835 | https://www.pexels.com/video/7679835/ |
| 6790438 | https://www.pexels.com/video/6790438/ |
| 15483596 | https://www.pexels.com/video/15483596/ |

Genel lisans: https://www.pexels.com/license/ . Yeni kurgu sırasında lisans sayfası ve 7677808, 12911888, 7679835, 6790438, 15483596 sayfalarına normal HTTPS erişimi yeniden denendi; altısında da ağ geçidi `Tunnel connection failed: 403 Forbidden` yanıtı verdi. Bu nedenle dosya düzeyinde bağımsız doğrulama sağlanamadı. Deneme kaydı: `pexels_checks/manifest.json`. Bu yeni kurguda kullanılan beş stok dosyası yukarıdaki tabloda listelenmiştir; 12625256 ve 5384976 kullanılmamıştır. Stokların içinde görünen marka, tanınabilir kişi, sanat eseri veya özel mekân için ayrıca haklar söz konusu olabilir. Lisans kaydı ve özgün sayfa bilgisi saklanmalıdır.

## Yazı tipleri, grafikler ve ses

- **Manrope:** Google Fonts'un resmî `google/fonts` kaynağından edinilmiş; SIL Open Font License 1.1. Yerel lisans: `../../fonts/Manrope-OFL.txt`. Resmî kaynak: https://github.com/google/fonts/tree/main/ofl/manrope .
- **Barlow Condensed ExtraBold:** Bu sürümün başlık fontudur. Google Fonts'un resmî `google/fonts` deposundaki `ofl/barlowcondensed` paketinden edinilmiştir; SIL Open Font License 1.1. Resmî kaynak: https://github.com/google/fonts/tree/main/ofl/barlowcondensed . Yerel dosya: `../../fonts/BarlowCondensed-ExtraBold.ttf`; lisans: `../../fonts/BarlowCondensed-OFL.txt`. Telif: Copyright 2017 The Barlow Project Authors.
- İstatistik kartları, şemalar, tipografi, geçişler ve takip çağrısı bu kurgu için hazırlanır. Instagram arayüzü kopyalanmaz. Özgün grafiklerde “Özgün grafik” kaynak etiketi yeterlidir; herhangi bir dış üretici uydurulmaz.
- Seslendirme: kullanıcının sağladığı `ElevenLabs_2026-10-17T14_49_20_Ece_gen_sp100_s50_sb75_v4.mp3`. Kullanım hakkı, üretim tarihindeki ElevenLabs planına ve seçilen sesin şartlarına bağlıdır. Kullanıcının ses dosyasını sağlaması abonelik koşullarının bağımsız kontrol edildiği anlamına gelmez.

## Ekrandaki kaynak gösterimi

Kaynak satırları sade ve düşük vurgulu olabilir, ancak **bulanıklaştırılmaz veya okunamayacak kadar küçültülmez**. Her alıntı kendi kaynağıyla, her stok kendi dosya kimliğiyle ilişkilendirilir. Tam uzun haber adresi yerine ekranda “Yıldırım Gazetesi • 06.10.2025” ve alan adı kullanılır; tam bağlantı paylaşım açıklamasında ve bu belgede yer alır.

6–8 saniyelik son kart, üç bilgi kaynağını özetler: 1. Gün videosu; GUMA Kullanım Şartları; Yıldırım Gazetesi, 6 Ekim 2025. Stok satırları yalnızca kullanılan kimlikleri listeler. Kaynaklar seslendirilmez. Özgün takip animasyonu bu kartla birlikte veya ardından çok kısa gösterilebilir; toplam süre üç dakikanın altında tutulur.

## Sürüm bilgisi

Tamamlanan MP4'ün ölçülen süresi **164,2 saniye (2 dakika 44,2 saniye)**. Kullanıcının sağladığı yeni anlatıcı kaydı yaklaşık 155,167 saniyedir. 155,2–162,2 saniye arasında kaynak kartı, 162,2–164,2 saniye arasında özgün takip kapanışı yer alır. Son dosya 1080×1920, 30 fps H.264/AAC biçimindedir. Baştan sona çözümleme hatasız tamamlanmış, 34 örnek kare incelenmiştir. Son ses ölçümü −16,02 LUFS ve −4,20 dBTP'dir. Ölçüm kaydı `../output/DOGRULAMA.json` dosyasındadır.
