# Yeni kurgu — içerik ve görsel kontrolü

17 Ekim 2026. İncelenenler: `v2/edit.py`, kaynak kayıtları ve 16 sahnelik yeni tasarım önizlemesi; bütçe, takipçi, şirket ilişkisi, kurucu alıntısı ve kaynak kartı ayrıca tam boyutlu incelendi.

- 50 bin TL “açıklanan bütçe planı” olarak etiketlenmiş; gerçekleşen toplam harcama olduğu iddia edilmiyor.
- 130 bin takipçi, videoda aktarılan önceki sayı/beyan olarak gösterilmiş; güncel GUMA hesabının ölçümü değil.
- Kurucunun dayısıyla ilgili söz, “gazetede aktarılan kurucu açıklaması” başlığı ve haber tarihiyle verilmiş.
- Saloni → GUMA şeması üretim/tedarik ile satış rollerini gösteriyor; mülkiyet veya ücretsiz üretim bağlantısı kurmuyor.
- İlk önizlemedeki şirket ilişkisi şemasının arkasındaki temsili atölye kaldırıldı. Güncel sahnede düz zemin ve özgün grafik var; bir stok tesisi Saloni'ye aitmiş gibi görünmüyor.
- Büyük metinlerde kritik kesilme veya taşma görülmedi. Türkçe karakterler doğru görünüyor. Kaynak alt satırları tam boy önizlemelerde okunabiliyor; bulanıklaştırılmamış.
- Kaynak kartı üç bilgi kaynağını ve kullanılan beş stok kimliğini listeliyor. Tam haber adresi paylaşım açıklamasında mevcut.
- Kaynak videonun özgün görüntü, ekran karesi veya sesini kullanan bir öğe renderer girdilerinde bulunmuyor. Beş stok, özgün grafikler ve kullanıcının yeni ElevenLabs kaydı kullanılıyor.
- Önizleme kontrolü hukuki inceleme, lisans teyidi veya baştan sona nihai MP4 teknik çözümleme kontrolü değildir. Nihai MP4 teknik doğrulaması ayrı teslim kaydında yapılır.

Bu kontrolde kalan kritik içerik veya görsel düzeltme saptanmadı. Pexels dosya sayfaları/lisans erişimi ve ElevenLabs abonelik koşullarının bağımsız teyidi, kaynak notlarında belirtilen sınırları korur.
